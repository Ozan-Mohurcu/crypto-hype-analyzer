# Takip edilecek coinler
COINS = {
    'bitcoin': 'BTC',
    'ethereum': 'ETH', 
    'solana': 'SOL',
    'dogecoin': 'DOGE',
    'cardano': 'ADA',
    'chainlink': 'LINK',
    'polygon': 'MATIC',
    'avalanche-2': 'AVAX'
}

# Reddit subredditler
SUBREDDITS = ['CryptoCurrency', 'Bitcoin', 'ethereum', 'solana', 'dogecoin']